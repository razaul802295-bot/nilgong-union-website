# নীলগঞ্জ ইউনিয়ন ওয়েবসাইট — Admin Panel Demo

ফাইল:
- index.html = Public website
- admin.html = Admin Panel
- style.css = Design
- app.js = Data management

ডেমো লগইন:
Username: admin
Password: 1234

গুরুত্বপূর্ণ:
এই ডেমোতে তথ্য browser-এর localStorage-এ থাকে। তাই একই কম্পিউটার/ব্রাউজারে কাজ করবে।
সব ডিভাইসে একই ডাটা দেখাতে Firebase/Supabase-এর মতো online database ও secure authentication যুক্ত করতে হবে।
ডেমো password বাস্তব অনলাইন সাইটে ব্যবহার করবেন না।
