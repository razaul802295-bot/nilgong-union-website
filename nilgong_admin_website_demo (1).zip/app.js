const KEY_P="nilgong_people", KEY_N="nilgong_notices";
const defaultPeople=[
 {id:"u1",type:"union",ward:"",name:"ইউনিয়ন দায়িত্বশীলের নাম",role:"সভাপতি",phone:"01XXXXXXXXX",photo:""},
 {id:"u2",type:"union",ward:"",name:"ইউনিয়ন দায়িত্বশীলের নাম",role:"সেক্রেটারি",phone:"01XXXXXXXXX",photo:""}
];
const defaultNotices=[
 {id:"n1",title:"স্বাগতম",text:"এখানে ইউনিয়ন ও ৯টি ওয়ার্ডের তথ্য এবং নোটিশ প্রকাশ করা যাবে।"}
];
function getPeople(){let x=localStorage.getItem(KEY_P);if(!x){localStorage.setItem(KEY_P,JSON.stringify(defaultPeople));return defaultPeople}return JSON.parse(x)}
function setPeople(x){localStorage.setItem(KEY_P,JSON.stringify(x))}
function getNotices(){let x=localStorage.getItem(KEY_N);if(!x){localStorage.setItem(KEY_N,JSON.stringify(defaultNotices));return defaultNotices}return JSON.parse(x)}
function setNotices(x){localStorage.setItem(KEY_N,JSON.stringify(x))}
function esc(s){return String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function renderPublic(){
 const people=getPeople(), notices=getNotices();
 const u=document.getElementById("unionList"), w=document.getElementById("wardList"), n=document.getElementById("noticeList");
 if(!u)return;
 u.innerHTML=people.filter(x=>x.type==="union").map(card).join("")||"<p>কোনো তথ্য নেই।</p>";
 function drawWards(q=""){
  const f=people.filter(x=>x.type==="ward" && (`${x.ward} ${x.name} ${x.role}`.toLowerCase().includes(q.toLowerCase())));
  w.innerHTML=Array.from({length:9},(_,i)=>{const no=["১","২","৩","৪","৫","৬","৭","৮","৯"][i];const arr=f.filter(x=>x.ward===no);return `<div class="card"><h3>${no} নং ওয়ার্ড</h3>${arr.length?arr.map(card).join(""):"<p class='small'>তথ্য যোগ করা হয়নি।</p>"}</div>`}).join("");
 }
 function card(x){return `<div class="person"><div class="avatar">${x.photo?`<img class="avatar" src="${esc(x.photo)}" alt="">`:esc((x.name||"?").charAt(0))}</div><div><h3>${esc(x.name)}</h3><div class="meta">${esc(x.role)}<br>${esc(x.phone)}</div></div></div>`}
 drawWards();
 document.getElementById("search").addEventListener("input",e=>drawWards(e.target.value));
 n.innerHTML=notices.map(x=>`<div class="notice"><b>${esc(x.title)}</b><p>${esc(x.text)}</p></div>`).join("");
}
function renderAdmin(){
 const p=getPeople(), n=getNotices(), ap=document.getElementById("adminPeople"), an=document.getElementById("adminNotices");
 if(!ap)return;
 ap.innerHTML=p.map(x=>`<div class="card"><b>${esc(x.name)}</b> — ${esc(x.role)} ${x.type==="ward"?`(${esc(x.ward)} নং ওয়ার্ড)`:"(ইউনিয়ন)"}<br><span class="small">${esc(x.phone)}</span><div class="actions"><button onclick="editPerson('${x.id}')">Edit</button><button class="danger" onclick="deletePerson('${x.id}')">Delete</button></div></div>`).join("")||"<p>তথ্য নেই।</p>";
 an.innerHTML=n.map(x=>`<div class="card"><b>${esc(x.title)}</b><p>${esc(x.text)}</p><div class="actions"><button onclick="editNotice('${x.id}')">Edit</button><button class="danger" onclick="deleteNotice('${x.id}')">Delete</button></div></div>`).join("")||"<p>নোটিশ নেই।</p>";
}
function savePerson(e){
 e.preventDefault();let p=getPeople(),id=document.getElementById("personId").value||Date.now().toString();
 const obj={id,type:document.getElementById("personType").value,ward:document.getElementById("wardNo").value,name:document.getElementById("personName").value.trim(),role:document.getElementById("personRole").value.trim(),phone:document.getElementById("personPhone").value.trim(),photo:document.getElementById("personPhoto").value.trim()};
 const i=p.findIndex(x=>x.id===id);if(i>=0)p[i]=obj;else p.push(obj);setPeople(p);resetPerson();renderAdmin();alert("তথ্য সংরক্ষণ হয়েছে।");
}
function editPerson(id){const x=getPeople().find(a=>a.id===id);if(!x)return;personId.value=x.id;personType.value=x.type;wardNo.value=x.ward;personName.value=x.name;personRole.value=x.role;personPhone.value=x.phone;personPhoto.value=x.photo;scrollTo(0,0)}
function deletePerson(id){if(confirm("এই তথ্যটি মুছবেন?")){setPeople(getPeople().filter(x=>x.id!==id));renderAdmin()}}
function resetPerson(){personForm.reset();personId.value=""}
function saveNotice(e){e.preventDefault();let n=getNotices(),id=noticeId.value||Date.now().toString(),obj={id,title:noticeTitle.value.trim(),text:noticeText.value.trim()},i=n.findIndex(x=>x.id===id);if(i>=0)n[i]=obj;else n.unshift(obj);setNotices(n);noticeForm.reset();noticeId.value="";renderAdmin();alert("নোটিশ সংরক্ষণ হয়েছে।")}
function editNotice(id){const x=getNotices().find(a=>a.id===id);if(!x)return;noticeId.value=x.id;noticeTitle.value=x.title;noticeText.value=x.text;scrollTo(0,document.body.scrollHeight)}
function deleteNotice(id){if(confirm("নোটিশটি মুছবেন?")){setNotices(getNotices().filter(x=>x.id!==id));renderAdmin()}}
renderPublic();